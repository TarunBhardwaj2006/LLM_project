# KMRL Train Induction & Yard Dispatch Optimization (CSE473)

## 1. Project Overview
Simulation-based digital twin of Kochi Metro Rail Limited (KMRL) Muttom Depot. Benchmarks a naive sequential First-Come, First-Served (FCFS) dispatch baseline against a multi-objective optimization agent with Chain-of-Thought (CoT) LLM operational reasoning.

## 2. Setup & Execution
- Python Version: 64-bit Python 3.11+ / 3.14
- Install dependencies:
  \\\ash
  pip install -r requirements.txt
  \\\
- Launch application:
  \\\ash
  streamlit run app.py
  \\\
- Access URL: http://localhost:8501

## 3. Individual Ownership & Contributions
- **Sole Contributor:** Tarun Bhardwaj
- **Core Deliverables:**
  - Designed simulated KMRL Muttom Depot digital twin environment (\KMRLDepotEnv\).
  - Implemented baseline FCFS dispatcher and multi-objective optimization algorithm.
  - Developed Chain-of-Thought (CoT) LLM operational reasoning layer and automated shift-handover reporting.
  - Built interactive Streamlit OCC console with Plotly yard spatial layouts.
