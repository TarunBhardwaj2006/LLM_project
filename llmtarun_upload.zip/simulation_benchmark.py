import numpy as np
import matplotlib.pyplot as plt
from app import KMRLDepotEnv

def run_benchmark(days=40):
    naive_delays, opt_delays = [], []
    for d in range(days):
        env = KMRLDepotEnv(num_rakes=25, required_service_rakes=16, seed=100 + d)
        naive_delays.append(env.run_policy('naive')['total_delay'])
        env._generate_yard()
        opt_delays.append(env.run_policy('optimized')['total_delay'])
    
    plt.figure(figsize=(10, 4.5))
    plt.plot(naive_delays, label='Naive FCFS Baseline', color='#d62728', marker='o', markersize=4)
    plt.plot(opt_delays, label='Optimized Schedule Agent', color='#2ca02c', marker='s', markersize=4)
    plt.title('KMRL Train Induction: Daily Cumulative Delay (40 Runs)')
    plt.xlabel('Operational Run Day')
    plt.ylabel('Delay (Minutes)')
    plt.grid(True, linestyle='--', alpha=0.6)
    plt.legend()
    plt.tight_layout()
    plt.savefig('kmrl_induction_performance_comparison.png', dpi=300)
    print('Benchmark plot saved successfully as kmrl_induction_performance_comparison.png')

if __name__ == '__main__':
    run_benchmark()
