import streamlit as st
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import json
import random

st.set_page_config(
    page_title="KMRL Train Induction - LLM Intelligent Dispatcher",
    page_icon="🚇",
    layout="wide"
)

# ==========================================
# 1. SIMULATION ENVIRONMENT
# ==========================================
class KMRLDepotEnv:
    def __init__(self, num_rakes=25, required_service_rakes=16, seed=42):
        np.random.seed(seed)
        random.seed(seed)
        self.num_rakes = num_rakes
        self.required_service_rakes = required_service_rakes
        self.rakes = []
        self._generate_yard()

    def _generate_yard(self):
        self.rakes = []
        for i in range(self.num_rakes):
            self.rakes.append({
                "rake_id": f"TS-{i+1:02d}",
                "mileage_km": int(np.random.randint(11000, 26000)),
                "fitness_days_left": int(np.random.choice([0, 2, 7, 15, 30], p=[0.08, 0.12, 0.25, 0.30, 0.25])),
                "has_class_a_defect": bool(np.random.choice([True, False], p=[0.12, 0.88])),
                "stabling_lane": (i % 5) + 1,
                "lane_depth": i // 5  # 0: Exit Gate, 1: Mid, 2: Back
            })

    def run_policy(self, agent_type="optimized"):
        if agent_type == "naive":
            selected_ids = [self.rakes[i]["rake_id"] for i in range(self.required_service_rakes)]
        else:
            eligible = []
            for r in self.rakes:
                if r["fitness_days_left"] > 0 and not r["has_class_a_defect"]:
                    cost = (r["lane_depth"] * 3.5) + ((r["mileage_km"] / 25000.0) * 1.5)
                    eligible.append((cost, r))
            eligible.sort(key=lambda x: x[0])
            chosen = [item[1] for item in eligible[:self.required_service_rakes]]
            chosen.sort(key=lambda x: (x["lane_depth"], x["stabling_lane"]))
            selected_ids = [r["rake_id"] for r in chosen]

        total_delay = 0.0
        shunting_conflicts = 0
        safety_violations = 0
        logs = []

        lane_dict = {}
        for r in self.rakes:
            lane_dict.setdefault(r["stabling_lane"], []).append(r)
        for l in lane_dict:
            lane_dict[l].sort(key=lambda x: x["lane_depth"])

        # Timeline starting at 05:30 AM
        current_time_minutes = 5 * 60 + 30 

        for rank, rid in enumerate(selected_ids):
            rake = next(r for r in self.rakes if r["rake_id"] == rid)
            delay_addition = np.random.uniform(1.2, 2.5)
            conflict_reason = []

            if rake["fitness_days_left"] <= 0 or rake["has_class_a_defect"]:
                safety_violations += 1
                delay_addition += 25.0
                conflict_reason.append("CRITICAL: Fitness Expired/Defect")

            blocking = [
                o for o in lane_dict[rake["stabling_lane"]]
                if o["lane_depth"] < rake["lane_depth"] and o["rake_id"] not in selected_ids[:rank]
            ]
            if len(blocking) > 0:
                shunting_conflicts += 1
                shunt_delay = len(blocking) * 12.0
                delay_addition += shunt_delay
                conflict_reason.append(f"Blocked by {len(blocking)} rake(s) (+{shunt_delay:.0f}m)")

            start_t = f"{current_time_minutes // 60:02d}:{current_time_minutes % 60:02d}"
            current_time_minutes += int(delay_addition + 5) # 5 min head interval
            end_t = f"{current_time_minutes // 60:02d}:{current_time_minutes % 60:02d}"

            total_delay += delay_addition
            logs.append({
                "Seq": rank + 1,
                "Rake": rid,
                "Lane": f"Line {rake['stabling_lane']}",
                "Depth": f"Pos {rake['lane_depth']}",
                "Departure Time": start_t,
                "Delay Added (min)": round(delay_addition, 1),
                "Status/Bottleneck": ", ".join(conflict_reason) if conflict_reason else "Clear Exit"
            })

        return {
            "selected_ids": selected_ids,
            "total_delay": round(total_delay, 1),
            "conflicts": shunting_conflicts,
            "violations": safety_violations,
            "logs": logs
        }

# ==========================================
# 2. LLM REASONING DISPATCHER ENGINE
# ==========================================
def generate_llm_reasoning_explanation(env, opt_results, naive_results):
    """
    Simulates Chain-of-Thought (CoT) LLM dispatcher reasoning.
    Transforms raw structured states into operational justifications.
    """
    total_defects = sum(1 for r in env.rakes if r["has_class_a_defect"])
    expired_cert = sum(1 for r in env.rakes if r["fitness_days_left"] <= 0)
    
    explanation = f"""### 🤖 LLM Agent Multi-Hop Reasoning & Audit Trail

**1. Context Ingestion & Guardrail Filtering:**
- Total Fleet: 25 trainsets at Muttom Depot.
- Hard Safety Violations Filtered: Found **{total_defects} rakes** with active Class-A technical defects and **{expired_cert} rakes** with expired mandatory safety certificates.
- *LLM Decision:* Struck these rakes immediately from revenue induction queue. Assigned to Heavy Maintenance Bay.

**2. Spatial Geometry & LIFO Yard Optimization:**
- Evaluated physical stabling track depth (0 = Clear exit to Muttom mainline, 1 = Intermediate, 2 = Bottleneck rear stack).
- *LLM Dispatch Sequence Policy:* Dispatched shallow rakes (Depth 0) first across Stabling Lines 1–5. This unlocked access pathways for deeper rakes without requiring auxiliary shunting locomotives.

**3. Comparative Operational Delta:**
- **Baseline Naive Dispatch (FCFS):** Would have caused **{naive_results['conflicts']} shunting track blockages** and **{naive_results['violations']} fatal safety dispatch infractions**, totaling **{naive_results['total_delay']} minutes** of cumulative morning induction delays.
- **LLM Induction Optimization:** Delays curtailed to **{opt_results['total_delay']} minutes** (Net **{((naive_results['total_delay']-opt_results['total_delay'])/naive_results['total_delay'])*100:.1f}% efficiency gain**). Zero safety compliance infractions.
"""
    return explanation

# ==========================================
# 3. SIDEBAR CONTROLS
# ==========================================
st.sidebar.title("🚇 KMRL OCC Console")
st.sidebar.markdown("**Muttom Depot Train Induction Engine**")

sim_seed = st.sidebar.number_input("Depot Simulation Seed", min_value=1, max_value=9999, value=101, step=1)
required_rakes = st.sidebar.slider("Morning Peak Requirement (Rakes)", min_value=12, max_value=20, value=16)

st.sidebar.subheader("🚨 What-If Scenario Injector")
blocked_lane = st.sidebar.selectbox("Simulate Track Bottleneck / Fault", ["None", "Line 1 Blocked", "Line 3 Power Outage", "Line 5 Point Failure"])

env = KMRLDepotEnv(num_rakes=25, required_service_rakes=required_rakes, seed=sim_seed)

# Handle What-If injection
if blocked_lane != "None":
    lane_num = int(blocked_lane.split()[1])
    for r in env.rakes:
        if r["stabling_lane"] == lane_num:
            r["has_class_a_defect"] = True

naive_results = env.run_policy("naive")
opt_results = env.run_policy("optimized")

# ==========================================
# 4. DASHBOARD HEADER & KPIS
# ==========================================
st.title("🚇 KMRL Autonomous Train Induction & Yard Dispatcher")
st.caption("Powered by Constrained State Optimization & LLM Operational Reasoning (Muttom Yard, Kochi)")

col1, col2, col3, col4 = st.columns(4)
pct_gain = ((naive_results["total_delay"] - opt_results["total_delay"]) / naive_results["total_delay"]) * 100

col1.metric("Optimized Induction Delay", f"{opt_results['total_delay']} min", delta=f"{opt_results['total_delay'] - naive_results['total_delay']:.1f} min", delta_color="inverse")
col2.metric("Efficiency Gain", f"{pct_gain:.1f}%")
col3.metric("Shunting Conflicts", f"{opt_results['conflicts']}", delta=f"{opt_results['conflicts'] - naive_results['conflicts']}", delta_color="inverse")
col4.metric("Safety Violations", f"{opt_results['violations']}", delta=f"{opt_results['violations'] - naive_results['violations']}", delta_color="inverse")

st.divider()

# ==========================================
# 5. LLM REASONING TAB & YARD LAYOUT
# ==========================================
tab_reasoning, tab_yard, tab_schedule = st.tabs([
    "🧠 LLM Reasoning & Incident Report",
    "📍 Interactive Yard Stabling Layout",
    "📋 Dispatch Timetable & CSV Export"
])

with tab_reasoning:
    st.markdown(generate_llm_reasoning_explanation(env, opt_results, naive_results))
    
    # Downloadable Executive Report
    report_text = f"""KMRL MUTTOM DEPOT - MORNING INDUCTION SHIFT REPORT
Date: Operational Shift Morning (05:30 - 08:30)
Simulation Seed: {sim_seed}
Service Rakes Required: {required_rakes}

EXECUTIVE SUMMARY:
- Optimized Departure Delay: {opt_results['total_delay']} mins
- Baseline FCFS Delay: {naive_results['total_delay']} mins
- Total Delay Reduction: {pct_gain:.2f}%
- Track Shunting Conflicts: {opt_results['conflicts']}
- Safety & Certificate Violations: 0

DISPATCHED RAKES (SEQUENCE):
{', '.join(opt_results['selected_ids'])}
"""
    st.download_button(
        label="📥 Download Official Shift Handover Report (.txt)",
        data=report_text,
        file_name=f"KMRL_Induction_Report_Seed_{sim_seed}.txt",
        mime="text/plain"
    )

with tab_yard:
    st.caption("Visual representation of Stabling Lanes 1 to 5. Depth 0 indicates front exit to mainline.")
    yard_df = pd.DataFrame(env.rakes)
    yard_df["Status"] = "Ready"
    yard_df.loc[yard_df["fitness_days_left"] <= 0, "Status"] = "Expired Certificate"
    yard_df.loc[yard_df["has_class_a_defect"] == True, "Status"] = "Technical Defect"

    opt_set = set(opt_results["selected_ids"])
    yard_df["Induction State"] = yard_df["rake_id"].apply(lambda x: "Inducted into Revenue" if x in opt_set else "Stabled / Maintenance")

    fig_yard = px.scatter(
        yard_df,
        x="stabling_lane",
        y="lane_depth",
        color="Induction State",
        symbol="Status",
        size=[26] * len(yard_df),
        text="rake_id",
        hover_data=["mileage_km", "fitness_days_left", "Status"],
        labels={"stabling_lane": "Depot Stabling Lane (Line 1 - 5)", "lane_depth": "Track Depth (0 = Front Exit)"},
        color_discrete_map={"Inducted into Revenue": "#2ca02c", "Stabled / Maintenance": "#d62728"}
    )
    fig_yard.update_traces(textposition="middle center", textfont=dict(color="white", size=10))
    fig_yard.update_yaxes(autorange="reversed", dtick=1)
    fig_yard.update_xaxes(dtick=1)
    fig_yard.update_layout(height=380, margin=dict(l=20, r=20, t=20, b=20))
    st.plotly_chart(fig_yard, use_container_width=True)

with tab_schedule:
    st.caption("Timetable showing departure sequence starting at 05:30 AM.")
    sched_df = pd.DataFrame(opt_results["logs"])
    st.dataframe(sched_df, use_container_width=True)
    
    # CSV Export
    csv_data = sched_df.to_csv(index=False).encode('utf-8')
    st.download_button(
        label="📥 Download Schedule as CSV",
        data=csv_data,
        file_name=f"KMRL_Induction_Timetable_Seed_{sim_seed}.csv",
        mime="text/csv"
    )